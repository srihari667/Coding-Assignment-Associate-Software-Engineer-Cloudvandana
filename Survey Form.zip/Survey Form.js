const surveyForm = document.getElementById('surveyForm');
const popup = document.getElementById('popup');
const popupData = document.getElementById('popup-data');
const closePopup = document.getElementById('close-popup');
const resetButton = document.getElementById('reset');
const submitButton = document.getElementById('submit');

surveyForm.addEventListener('submit', function(e) {
    e.preventDefault();
    popupData.innerHTML = '';

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const country = document.getElementById('country').value;
    const dob = document.getElementById('dob').value;
    popupData.innerHTML += `<li>Name: ${name}</li>`;
    popupData.innerHTML += `<li>Email: ${email}</li>`;
    popupData.innerHTML += `<li>Country: ${country}</li>`;
    popup.style.display = 'block';
    surveyForm.reset();
});

closePopup.addEventListener('click', function() {
    popup.style.display = 'none';
    surveyForm.reset();
});

resetButton.addEventListener('click', function() {
    surveyForm.reset();
});